#include "pch.h"
#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

string userInput, passInput, passMatch, titleMatch, display;

int attempts = 0;

//defining a users parameters
struct users {
    string username;
    string md5;
    string password;
    string title;
};

//vector of users
vector<users> user;

// function to copy data from credential.txt into an array
void getCredentialsList() {
    //Reading credentials.txt file into an array
    ifstream file("credentials.txt");

    if (!file) {
        cout << "Error reading file. Program cannot continue.";
        exit;
    }

    // vector to hold data from credential.txt -- making it dynamic over an array
    vector<string>credentials;

    string element;
    while (file >> element) {
        credentials.push_back(element);
    }

    // feeding the credentials vector into the users struct vector
    for (int j = 0; j <= credentials.size(); j++) {
        for (int x = 0; x < credentials.size() / 4; x++) {
            user.push_back(users());
            user[x].username = credentials[x * 4];
            user[x].md5 = credentials[x * 4 + 1];
            user[x].password = credentials[x * 4 + 2];
            user[x].title = credentials[x * 4 + 3];
        }
    }
}

// function to check usernames and passwords
void checkPasswords(string userInput, string passInput){
   
    //checks to see if the entered username matches a known user and pulls matching password and job title file
    for (int k = 0; k < user.size() / 12; k++) {
        if (userInput == user[k].username) {
            passMatch = user[k].password;
            titleMatch = user[k].title + ".txt";
        }
    }
    //checks for correct password. If it's correct, prints the matching job title txt file
    if (passInput == passMatch) {
        string word;
        ifstream job;
        job.open(titleMatch);
        if (!job) {
            cout << "Error reading file. Program cannot continue." << endl;
            exit;
        }
        
        //prints the text file line-by-line
        while (getline(job, word)) {
            cout << word << endl;
        }
        
        attempts = 4;
    }
    //message for an incorrect login attempt
    else {
        cout << "Username or password is incorrect." << endl;
        cout << endl;
        attempts++;
    }
}


int main()
{
    getCredentialsList();
    
    //Setting the limit for failed passwords
    while (attempts < 3) {
        cout << "Enter your username: ";
        cin >> userInput;

        cout << "Enter your password: ";
        cin >> passInput;
        cout << endl;
        //calling function to check passwords
        checkPasswords(userInput, passInput);

        //exits after 3 failed attempts
        if (attempts == 3) {
            cout << "Maximum number of attempts reached.  Program will now exit." << endl;
            exit;
        }
    }
        
    return 0;
}
