package FinalProject;

import java.util.*;
import java.io.*;
import java.security.MessageDigest;


public class FinalProject {
    public static void main(String[] args) throws Exception{
        
        //Setting up scanners
	FileInputStream fileByteStream = null;
	fileByteStream = new FileInputStream("c:\\users\\drick\\desktop\\FinalProject\\src\\finalproject\\credentials.txt");
	Scanner scnr = new Scanner(fileByteStream);
	Scanner input = new Scanner(System.in);
        
    // Variables for counting loops
    int a = 0;
    int x = 1;
    int y = 0;
    int z = 2;
        
    // Initializing variables
    String userInputName = "";
	String userInputPassword = "";
    String passwordToMatch = ""; 
    String jobTitleMatch = "";
        
	//Variables for user 1
	String userName1 = "";
	String md5Hash1 = "";
	String passWord1 = "";
	String jobTitle1 = "";
    
	//Variables for user 2
	String userName2 = "";
	String md5Hash2 = "";
	String passWord2 = "";
	String jobTitle2 = "";
    
	//Variables for user 3
	String userName3 = "";
	String md5Hash3 = "";
	String passWord3 = "";
	String jobTitle3 = "";
	
	//Variables for user 4
	String userName4 = "";
	String md5Hash4 = "";
	String passWord4 = "";
	String jobTitle4 = "";
	
	//Variables for user 5
	String userName5 = "";
	String md5Hash5 = "";
	String passWord5 = "";
	String jobTitle5 = "";
	
	//Variables for user 6
	String userName6 = "";
	String md5Hash6 = "";
	String passWord6 = "";
	String jobTitle6 = "";
	
	//Defining reference variables
	Login user1 = new Login();
	Login user2 = new Login();
	Login user3 = new Login();
	Login user4 = new Login();
	Login user5 = new Login();
	Login user6 = new Login();
	
    // Setting up lists
	List<String> newArray = new ArrayList<>();
    List<String> userNameList = new ArrayList<>();
	List<String> md5List = new ArrayList<>();
	List<String> passWordList = new ArrayList<>();
	List<String> jobTitleList = new ArrayList<>();
	
        // Adding all elements of credential.txt into a list
	while (scnr.hasNext()) {
            newArray.add(scnr.next());
        }
        // Combining password variables back together after they were split by scnr.next()
        while (z < 17)  {
            String i = newArray.get(z); 
            String j = newArray.get(z + 1);
            i= i.concat(" " + j);
            newArray.set(z, i);
            newArray.remove(z + 1);
            z = z + 4; 
        }
        
      
        // Reading respective elements into their individual lists
        for (y = 0; y < newArray.size(); y = y + 4) {
                      
                userNameList.add(newArray.get(y));
        }
        for (y = 1; y < newArray.size(); y = y + 4) {
                      
                md5List.add(newArray.get(y));
        }
        for (y = 2; y < newArray.size(); y = y + 4) {
                      
                passWordList.add(newArray.get(y));
        }  
        for (y = 3; y < newArray.size(); y = y + 4) {
                      
                jobTitleList.add(newArray.get(y));
        }
	
        // Moving list elements into objects for each user
	user1.setUserName(userNameList.get(0));
	user1.setMd5Hash(md5List.get(0));
	user1.setPassWord(passWordList.get(0));
	user1.setJobTitle(jobTitleList.get(0));
	
	user2.setUserName(userNameList.get(1));
	user2.setMd5Hash(md5List.get(1));
	user2.setPassWord(passWordList.get(1));
	user2.setJobTitle(jobTitleList.get(1));
	
	user3.setUserName(userNameList.get(2));
	user3.setMd5Hash(md5List.get(2));
	user3.setPassWord(passWordList.get(2));
	user3.setJobTitle(jobTitleList.get(2));
	
	user4.setUserName(userNameList.get(3));
	user4.setMd5Hash(md5List.get(3));
	user4.setPassWord(passWordList.get(3));
	user4.setJobTitle(jobTitleList.get(3));
	
	user5.setUserName(userNameList.get(4));
	user5.setMd5Hash(md5List.get(4));
	user5.setPassWord(passWordList.get(4));
	user5.setJobTitle(jobTitleList.get(4));
	
	user6.setUserName(userNameList.get(5));
	user6.setMd5Hash(md5List.get(5));
	user6.setPassWord(passWordList.get(5));
	user6.setJobTitle(jobTitleList.get(5));
	
        // Loop to check user's inputted username against each individual user and set password and job for each
	for (x = 0; x < 99; ++x) {
            if (user1.getUserName().equals(userInputName)) {
                passwordToMatch = user1.getMd5Hash();
                jobTitleMatch = user1.getJobTitle();
                break;
            }
            else if (user2.getUserName().equals(userInputName)){
                passwordToMatch = user2.getMd5Hash();
                jobTitleMatch = user2.getJobTitle();
                break;
            }
            else if (user3.getUserName().equals(userInputName)){
                passwordToMatch = user3.getMd5Hash();
                jobTitleMatch = user3.getJobTitle();
                break;
            }else if (user4.getUserName().equals(userInputName)){
                passwordToMatch = user4.getMd5Hash();
                jobTitleMatch = user4.getJobTitle();
                break;
            }
            else if (user5.getUserName().equals(userInputName)){
                passwordToMatch = user5.getMd5Hash();
                jobTitleMatch = user5.getJobTitle();
                break;
            }
            else if (user6.getUserName().equals(userInputName)){
                passwordToMatch = user6.getMd5Hash();
                jobTitleMatch = user6.getJobTitle();
                break;
            }
            else {
                System.out.println("Please enter your username: ");
                userInputName = (input.nextLine());	
            }
        }    
        
        // Getting user input or password
        System.out.println("Please enter your password: ");
        userInputPassword = (input.nextLine());
		
        // Copied code to convert user's password to Md5hash for matching
        String original = userInputPassword;  //Replace "password" with the actual password inputted by the user
        MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(original.getBytes());
        byte[] digest = md.digest();
        StringBuffer sb = new StringBuffer();
        for (byte b : digest) {
            sb.append(String.format("%02x", b & 0xff));
        }
        // New scanners to read the job files
	FileInputStream admin = null;
	admin = new FileInputStream("c:\\users\\drick\\desktop\\FinalProject\\src\\finalproject\\admin.txt");
	Scanner adminScanner = new Scanner(admin);
        
        FileInputStream vet = null;
	vet = new FileInputStream("c:\\users\\drick\\desktop\\FinalProject\\src\\finalproject\\veterinarian.txt");
	Scanner vetScanner = new Scanner(vet);
        
        FileInputStream zookeeper = null;
	zookeeper = new FileInputStream("c:\\users\\drick\\desktop\\FinalProject\\src\\finalproject\\zookeeper.txt");
	Scanner zooScanner = new Scanner(zookeeper);
        
        
        // Loop to check if password matches for logged user and print job file if correct password -- limited to 3 attempts
        for (x = 0; x < 3; ++x){    
            if (sb.toString().equals(passwordToMatch)) {
                if (jobTitleMatch.equals("admin")) {
                    while (adminScanner.hasNextLine()){
                        System.out.print(adminScanner.nextLine() + " ");
                    }
                }
                else if (jobTitleMatch.equals("veterinarian")) {
                    while (vetScanner.hasNextLine()){
                        System.out.print(vetScanner.nextLine() + " ");
                    }
                }
                else if (jobTitleMatch.equals("zookeeper")) {
                    while (zooScanner.hasNextLine()){
                        System.out.print(zooScanner.nextLine() + " ");
                    }
                }    
                
            }
            else {
                System.out.println("Please enter your password: ");
                userInputPassword = (input.nextLine());
                if (x == 1) {
                    System.out.println("3 failed login attempts.  System will now exit");
                    break;
                }
            
            
            
            }
            
            
        }        	
		
		
    }
}
	
	
	
	
		
   
   
   
   
   
   
   
   
   
  