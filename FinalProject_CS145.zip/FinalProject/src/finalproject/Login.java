package FinalProject;

public class Login {
    //private fields
    private String userName;
    private String md5Hash;
    private String passWord;
    private String jobTitle;
    //Default constructor
    public Login() {
    	this.userName = "none";
	this.md5Hash = "none";
	this.passWord = "none";
	this.jobTitle = "none";
    }
    //Login object with implicit parameters
    public Login(String userName, String md5Hash, String passWord, String jobTitle)
    {
	this.userName = userName;
	this.md5Hash = md5Hash;
        this.passWord = passWord;
	this.jobTitle = jobTitle;
    }		
    // Setting user name
    public void setUserName(String userName)
    {
        this.userName = userName;
    }
    // Getting user name
    public String getUserName()
    {
        return userName;
    }
    // Setting md5 hash
    public void setMd5Hash(String md5Hash)
    {
        this.md5Hash = md5Hash;
    } 
    // Getting md5 hash.
    public String getMd5Hash()
    {
        return md5Hash;
    }
    // Setting password
    public void setPassWord(String passWord)
    {
        this.passWord = passWord;
    }
    // Getting password
    public String getPassWord()
    {
        return passWord;
    }
	// Setting job title
    public void setJobTitle (String jobTitle)
    {
        this.jobTitle = jobTitle;
    }
    // Getting job title
    public String getJobTitle()
    {
        return jobTitle;
    }
}