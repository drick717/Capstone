#include "pch.h"
#include <iostream>
#include <fstream>
#include <string>


using namespace std;

string userInput, passInput, passMatch, titleMatch, display;
string credentials[24], username[6], md5[6], password[6], title[6];
int attempts = 0;


int main()
{
    //Reading credentials.txt file into an array
    ifstream file("credentials.txt");
    
    if (!file) {
        cout << "Error reading file. Program cannot continue.";
        return 1;
    }
    
    for (int i = 0; i < 24; i++) {
        file >> credentials[i];
    }
   
    //Splitting credentials array into 4 separate arrays
    for (int j = 0; j < 24; j++) {
        for (int x = 0; x < 6; x++) {
            username[x] = credentials[x * 4];
            md5[x] = credentials[x * 4 + 1];
            password[x] = credentials[x * 4 + 2];
            title[x] = credentials[x * 4 + 3];
        }
    }
        
    //Setting the limit for failed passwords
    while (attempts < 3) {
    
        cout << "Enter your username: ";
        cin >> userInput;

        cout << "Enter your password: ";
        cin >> passInput;

        cout << endl;

        //checks to see if username is in the username array and pulls matching password and job title file
        for (int k = 0; k < 6; k++) {
            if (userInput == username[k]) {
                passMatch = password[k];
                titleMatch = title[k] + ".txt";
            }
        }
        //checks for correct password. If it's correct, prints the matching job title txt file
        if (passInput == passMatch) {
            ifstream job(titleMatch);
            
            if (!job) {
                cout << "Error reading file. Program cannot continue." << endl;
                return 1;
            }
            
            while (getline(job, display)) {
                cout << display;
            }
            cout << titleMatch;
            attempts = 4;
        }
        //message for an incorrect login attempt
        else {
            cout << "Username or password is incorrect." << endl;
            cout << endl;
            attempts++;
        }
        //exits after 3 failed attempts
        if (attempts == 3) {
            cout << "Maximum number of attempts reached.  Program will now exit." << endl;
            return 1;
        }

    }
        
    return 0;
}
