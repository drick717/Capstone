#include <iostream>
#include <string>

#include "sqlite/sqlite3.h"

using namespace std;

int answer, rc;
string animName, animSpecies, animAge, animStatus, query;
char* err;
sqlite3* db;
sqlite3_stmt* stmt;
const unsigned char* name;
const unsigned char* species;
int age;
const unsigned char* sex;
const unsigned char* status;
char animSex;

// caalback function for sqlite
int callback(void* NotUsed, int argc, char** argv, char** azColName) {

    // Return successful
    return 0;
}

// function that displays a menu to allow for CRUD functions using sqlite
void zooMenu() {

    do {
        cout << endl;

        cout << "Welcome to the zoo management system.  Please make a selection: " << endl;

        cout << "1: Enter a new animal: " << endl;

        cout << "2: Update an animal's age and status: " << endl;

        cout << "3: Display an animal's information: " << endl;

        cout << "4: Display all animals information: " << endl;

        cout << "5: Delete an animal: " << endl;

        cout << "6. Exit" << endl;

        cout << endl;

        cin >> answer;
        
        // switch/case menu that allows a user to manipulate the SQL table
        switch (answer) {
        case 1:  // creating a new animal entry
            cout << "Enter a new animal (name, species, age, sex, status): " << endl;
            cin >> animName >>animSpecies >> animAge >> animSex >> animStatus;
            
            query = "INSERT INTO animals VALUES ('" + animName + "', '" + animSpecies + "'," + animAge + ", '" + animSex + "', '" + animStatus + "');";

            rc = sqlite3_exec(db, query.c_str(), callback, 0, &err);
            if (rc != SQLITE_OK) {
                cout << "Error: " << err;
            }
            
            break;
        
        case 2: // updating an entry
            cout << "Enter the name of the animal you would like to update: " << endl;
            cin >> animName;
            cout << "Enter the updated age and status: " << endl;
            cin >> animAge >> animStatus;
            
            query = "UPDATE animals SET age =" + animAge + ", status = '"+ animStatus + "' WHERE name ='" + animName + "';";

            rc = sqlite3_exec(db, query.c_str(), callback, 0, &err);
            if (rc != SQLITE_OK) {
                cout << "Error: " << err;
            }

            break;
        
        case 3:  // displaying a specific animal by name
            cout << "Enter an animal's name: " << endl;

            cin >> animName;
           
            query = "SELECT * FROM animals WHERE name = '" + animName + "';";
            sqlite3_prepare_v2(db, query.c_str(), -1, &stmt, 0);
            while (sqlite3_step(stmt) != SQLITE_DONE) {
                name = sqlite3_column_text(stmt, 0);
                species = sqlite3_column_text(stmt, 1);
                age = sqlite3_column_int(stmt, 2);
                sex = sqlite3_column_text(stmt, 3);
                status = sqlite3_column_text(stmt, 4);
                
                cout << name << " " << species << " " << age << " " << sex << " " << status << endl;
                
            }
            
            break;

        case 4:  // displaying all animals
            
            query = "SELECT * FROM animals";
            sqlite3_prepare_v2(db, query.c_str(), -1, &stmt, 0);
            
            while (sqlite3_step(stmt) != SQLITE_DONE) {
                name = sqlite3_column_text(stmt, 0);
                species = sqlite3_column_text(stmt, 1);
                age = sqlite3_column_int(stmt, 2);
                sex = sqlite3_column_text(stmt, 3);
                status = sqlite3_column_text(stmt, 4);
                
                cout << name << " " << species << " " << age << " " << sex << " " << status << endl;
                
            }
            
            break;
            

        case 5:  // removing an animal's entry
            cout << "Enter an animal's name to delete: " << endl;

            cin >> animName;
            
            query = "DELETE FROM animals WHERE name = '" + animName + "';";

            rc = sqlite3_exec(db, query.c_str(), callback, 0, &err);
            if (rc != SQLITE_OK) {
                cout << "Error: " << err;
            }
            break;
        
        case 6: // quit option
            break;
            exit;
        default:
            cout << "Invalid selection. Please try again." << endl;

        }
    } while (answer >= 0 && answer < 6);


}
int main()
{
   
    // connecting to the database
    sqlite3_open("zoo.db", &db);

    // creates the table if it doesn't already exist
    int rc = sqlite3_exec(db, "CREATE TABLE IF NOT EXISTS animals(name varchar(255), species varchar(255), age int, sex varchar(1), status varchar(255));", callback, 0, &err);
    if (rc != SQLITE_OK) {
        cout << "Error: " << err;
    } 
    
    zooMenu();
    
    return 0;
}

